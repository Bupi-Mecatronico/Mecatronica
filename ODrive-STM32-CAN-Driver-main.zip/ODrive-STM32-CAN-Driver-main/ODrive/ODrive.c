/*
 * ODrive.c
 *
 *  Created on: 07-Jul-2022
 *      Author: sidiyer27
 */

/** @brief Este archivo contiene las funciones finales que se conjugan con las funciones de manejo de registros vistas en CAN.c
 * 
 * Las funciones mostradas en este archivo se dirigen hacia la descomposicion de los datos de gran tamano que se desean enviar
 * para ser almacenados en variables mas pequenas aplicando correciones de tipo, para reorganizarse en little endian y ser cargadas
 * a las funciones de envio de datos de CAN.c
 * 
 */
#include "ODrive.h"

/*Aqui se crean las instancias de las estructuras que contienen las variables que configuraran los registros y alamcenaran
 las configuraciones mismas en el codigo que sigue.*/

CAN_TX_Typedef TX;
CAN_RX_Typedef RX;
CAN_Filter_TypeDef filter;
CAN_Init_Typedef CAN;


/** @brief Esta funcion contiene las configuraciones iniciales de la comunicacion CAN.
 * 
 * @details dentro de esta funcion se ingresan las funciones vistas en CAN.c como CAN_Filter_Init para configurar los IDs permitidos
 * en el bus de datos CAN, tambien se usa CAN_Init(&CAN) para configurar los registros de configuracion de la libreria HUGE_VAL y se usa
 * CAN_start(&CAN) para dejar operativo y funcionando el protocolo en la MCU.
 * 
 * @note HAL_NVIC_SetPriority y HAL_NVIC_EnableIRQ se usan para configurar la prioridad y habilitar la interrupcion respectivamente.
 * El NVIC es el controlador/gestionador de interrupciones dentro del STM32, es una parte fundamental de la arquitectura ARM ya que permite
 * asignar prioridad a las interrupciones para evitar que una interrupcion menos relevante se interponga frente a otra interrupcion que ya esta
 * en proceso.
 * 
 */


void CAN_Setup(CAN_TypeDef *CAN_INSTANCE, int32_t baudrate){
	  CAN.CAN_INSTANCE = CAN_INSTANCE;
	  CAN.baudrate = baudrate;
	  CAN.interrupt = Fifo0_Message_Pending;
	  CAN_Init(&CAN);
	  filter.ID = 0x0;
	  filter.filter_id = 0;
	  filter.id_type = CAN_ID_Standard;
	  filter.frame_type = CAN_Frame_Data;
	  CAN_Filter_Init(&CAN, &filter);
	  CAN_Start(&CAN);
	  __disable_irq();
	  HAL_NVIC_SetPriority(CAN1_RX0_IRQn, 0, 0);
	  HAL_NVIC_EnableIRQ(CAN1_RX0_IRQn);
	  __enable_irq();
}



//Aqui se configuran los parametros basicos de la estructura TX vista en CAN.h donde se explican los miembros que componen la estructura.
void Set_TX_Param(int AXIS_ID, int COMMAND_ID, int id_type, int frame_type, int data_length){
	TX.ID = (AXIS_ID << 5) | COMMAND_ID;
	TX.id_type = id_type;
	TX.frame_type = frame_type;
	TX.data_length = data_length;
}


/** @brief Esta funcion se encarga de enviar los comandos de configuracion de los ejes al Odrive. 
 * 
 * ODrive tiene varios estados posibles para los motores, como:

 AXIS_STATE_IDLE (0)
 AXIS_STATE_STARTUP_SEQUENCE (1)
 AXIS_STATE_FULL_CALIBRATION_SEQUENCE (3)
 AXIS_STATE_CLOSED_LOOP_CONTROL (8)
 etc.
 Cuando el ODrive recibe este mensaje, cambia el estado del eje especificado (Axis.AXIS_ID) al nuevo estado state.

 @example Si quisieramos cambiar el estado de un motor a Closed Loop Control (PID activado) usaraiamos:

 Set_Axis_Requested_State(motor1, AXIS_STATE_CLOSED_LOOP_CONTROL);

 Esto enviaría un frame CAN con:
 ID: motor1.AXIS_ID
 Comando: SET_AXIS_REQUESTED_STATE
 Datos: 0x08 00 00 00 (para AXIS_STATE_CLOSED_LOOP_CONTROL)

 @details la linea: 
 uint8_t *ptrToFloat;
 ptrToFloat = (uint8_t *)&Requested_State;

 Son el llamado Type-Casting o Correciones de tipo, donde el tipo de dato original se reinterpreta en un nuevo tipo de dato.
 la variable Requested_State es de 32 bits (En STM32 int vale 32 bits), por lo tanto al usar (uint8_t *)&Requested_State; se accede a la
 direccion de memoria de la variable y se reinterpreta como si fuera un dato de 8 bits, esto parte en 4 bytes el dato original y permite 
 acceder a el byte por byte, que es justo lo que el protocolo CAN solicita para poder enviar los mensajes, entonces una vez
 reinterpretado el dato y partido en 4 bytes cada byte individual se asigna a un indice del arreglo TX.data y se envia con la funcion 
 de CAN.h llamada CAN_Send_Packet.

 */
void Set_Axis_Requested_State(Axis Axis, Axis_State state){
	Set_TX_Param(Axis.AXIS_ID, SET_AXIS_REQUESTED_STATE, CAN_ID_Standard, CAN_Frame_Data, 4);
	unsigned int Requested_State = state;
	uint8_t *ptrToFloat;
	ptrToFloat = (uint8_t *)&Requested_State;
	TX.data[0] = ptrToFloat[0];
	TX.data[1] = ptrToFloat[1];
	TX.data[2] = ptrToFloat[2];
	TX.data[3] = ptrToFloat[3];
	CAN_Send_Packet(&CAN, &TX);
}

/** @brief Esta funcion se encarga de configurar el torque y la velocidad de los motores.
 * 
 * @details En este caso se envia un frame CAN con:
 * ID: motor1.AXIS_ID
 * Comando: SET_INPUT_VEL
 * 
 * y el formato que sigue es identico al anterior, como se menciono en otras partes del codigo el formato nativo de los Odrive establece
 * que los primeros 4 bytes son un dato especifico y los otros 4 bytes son otro dato diferente, por lo que la funcion envia tanto torque en
 * los ultimos 4 bytes como velocidad en los primeros 4 bytes, descomponiendo el dato de 32 bits en uno de 8 bits cada parte.
 * 
 * @note la funcion Set_TX_Param se llama al inicio de cada funcion de envio de datos, ya que la funcion configura el ID del motor y la instruccion,
 * por lo tanto como cada funcion de envio de datos tiene un ID de motor nuevo y una instruccion diferente la estructura TX
 * debe actualizar constantemente sus IDs con la funcion Set_TX_Param.
 */

void Set_Input_Vel(Axis Axis, float vel, float torqueff){
	Set_TX_Param(Axis.AXIS_ID, SET_INPUT_VEL, CAN_ID_Standard, CAN_Frame_Data, 8);
	uint8_t *ptrVel;
	ptrVel = (uint8_t *)&vel;
	uint8_t *ptrTor;
	ptrTor = (uint8_t *)&torqueff;
	TX.data[0] = ptrVel[0];
	TX.data[1] = ptrVel[1];
	TX.data[2] = ptrVel[2];
	TX.data[3] = ptrVel[3];
	TX.data[4] = ptrTor[0];
	TX.data[5] = ptrTor[1];
	TX.data[6] = ptrTor[2];
	TX.data[7] = ptrTor[3];
	CAN_Send_Packet(&CAN, &TX);
}

/** @brief solicita los errores del Odrive y los elimina de su almacenamiento
 * 
 * Cuando no se ve contenido dentro de la funcion es porque la instruccion es una solicitud de informacion, en funciones anteriores
 * se utilizaba type-casting para ingresar el dato byte a byte, sin embargo aqui no es necesario, por que las instrucciones que 
 * solicitan datos desdel el Odrive hacia el STM32 no requieren contenido adicional, solo el ID de la instruccion para pedir un dato en
 * especifico.
 * 
 * En este caso el ID esta alojado en el macro CLEAR_ERRORS que esta en el archivo CAN_Defines.h, este macro esconde el ID: 0x018 que es
 * el ID de la instruccion para solicitar los errores.
 */

void Clear_Errors(Axis Axis){
	Set_TX_Param(Axis.AXIS_ID, CLEAR_ERRORS, CAN_ID_Standard, CAN_Frame_Data, 0);
	CAN_Send_Packet(&CAN, &TX);
}


// Lo mismo que la funcion anterior, pero esta funcion produce un reinicio de la configuracion del Odrive (reseteo)



void Reboot_ODrive(Axis Axis){
	Set_TX_Param(Axis.AXIS_ID, REBOOT_ODRIVE, CAN_ID_Standard, CAN_Frame_Data, 0);
	CAN_Send_Packet(&CAN, &TX);
}

//Funcion que configura el modo de operacion del motor, ya sea por cordenadas absolutas, pasos motor, tipo de senal de control (digital, PWM) etc.

void Set_Controller_Modes(Axis Axis, Control_Mode ControlMode, Input_Mode InputMode){
	Set_TX_Param(Axis.AXIS_ID, SET_CONTROLLER_MODES, CAN_ID_Standard, CAN_Frame_Data, 8);
	int Control = ControlMode;
	int Input = InputMode;
	uint8_t *ptrControl;
	ptrControl = (uint8_t *)&Control;
	uint8_t *ptrInput;
	ptrInput = (uint8_t *)&Input;
	TX.data[0] = ptrControl[0];
	TX.data[1] = ptrControl[1];
	TX.data[2] = ptrControl[2];
	TX.data[3] = ptrControl[3];
	TX.data[4] = ptrInput[0];
	TX.data[5] = ptrInput[1];
	TX.data[6] = ptrInput[2];
	TX.data[7] = ptrInput[3];
	CAN_Send_Packet(&CAN, &TX);
}


/** @brief Funcion que se encarga del movimiento de los motores
 *  
 * @details Probablemente la funcion mas relevante de la libreria, esta funcion incorpora 3 datos en un solo envio, los 4 primeros bytes son la posicion
 * deseada, dependiendo de como se configure el Odrive desde la laptop con OdriveTool la forma en que se describe la posicion cambiara (si es
 * en pasos motor, angulos, posicion absoluta etc.), los siguientes 2 bytes son la velocidad deseada y los ultimos 2 bytes son la fuerza de
 * torque deseada para realizar este movimiento.
 * 
 * @example Transformamos los grados de la cinematica a pasos motor y usamos:
 * 
 * Set_Input_Pos(AXIS_1, 225, 1000, 25); //225 pasos, 1000rpm, 25 Newton-metros de fuerza.
 * 
 */

void Set_Input_Pos(Axis Axis, float Input_Pos, int Vel_FF, int Torque_FF){
	Set_TX_Param(Axis.AXIS_ID, SET_INPUT_POS, CAN_ID_Standard, CAN_Frame_Data, 8);
	uint8_t *ptrPos;
	ptrPos = (uint8_t *)&Input_Pos;
	uint8_t *ptrVel;
	ptrVel = (uint8_t *)&Vel_FF;
	uint8_t *ptrTor;
	ptrTor = (uint8_t *)&Torque_FF;
	TX.data[0] = ptrPos[0];
	TX.data[1] = ptrPos[1];
	TX.data[2] = ptrPos[2];
	TX.data[3] = ptrPos[3];
	TX.data[4] = ptrVel[0];
	TX.data[5] = ptrVel[1];
	TX.data[6] = ptrTor[0];
	TX.data[7] = ptrTor[1];
	CAN_Send_Packet(&CAN, &TX);
}


//Solicita el conteo del encoder para mostrar la posicion real del motor.

void Get_Encoder_Count(Axis Axis){
	Set_TX_Param(Axis.AXIS_ID, GET_ENCODER_COUNT, CAN_ID_Standard, CAN_Frame_Remote, 0);
	CAN_Send_Packet(&CAN, &TX);
}

//configura especificamente el torque

void Set_Input_Torque(Axis Axis, float torque){
	Set_TX_Param(Axis.AXIS_ID, SET_INPUT_TORQUE, CAN_ID_Standard, CAN_Frame_Data, 4);
	uint8_t *ptrTor;
	ptrTor = (uint8_t *)&torque;
	TX.data[0] = ptrTor[0];
	TX.data[1] = ptrTor[1];
	TX.data[2] = ptrTor[2];
	TX.data[3] = ptrTor[3];
	CAN_Send_Packet(&CAN, &TX);
}

//Obtiene el voltaje de la fuente de alimentacion, util para detectar caidas de voltaje y actuar en consecuencia.

void Get_Bus_Voltage_Current(Axis Axis){
	Set_TX_Param(Axis.AXIS_ID, GET_BUS_VOLTAGE_CURRENT, CAN_ID_Standard, CAN_Frame_Remote, 0);
	CAN_Send_Packet(&CAN, &TX);
}

//Obtiene la corriente de la fuente de alimentacion, util para detectar sobreconsumos
void Get_IQ(Axis Axis){
	Set_TX_Param(Axis.AXIS_ID, GET_IQ, CAN_ID_Standard, CAN_Frame_Remote, 0);
	CAN_Send_Packet(&CAN, &TX);
}


/** @brief Funcion que se encarga de configurar la ganancia de la posicion
 * 
 * Input_Pos movia el motor a la posicion deseada, Position_Gain cambia la ganancia de la parte proporcional del PDI
 * para conseguir un movimiento mas brusco o suave, si Position_Gain es bajo el movimiento es suave y lento, si es alto
 * actua con mas rapidez y fuerza. 
 * 
 * @note puede ser una posible entrada para ingresar el resultado Kp de la red neuronal del PID
 */

void Set_Position_Gain(Axis Axis, float pos_gain){
	Set_TX_Param(Axis.AXIS_ID, SET_POSITION_GAIN, CAN_ID_Standard, CAN_Frame_Data, 4);
	uint8_t *ptrPos;
	ptrPos = (uint8_t *)&pos_gain;
	TX.data[0] = ptrPos[0];
	TX.data[1] = ptrPos[1];
	TX.data[2] = ptrPos[2];
	TX.data[3] = ptrPos[3];
	CAN_Send_Packet(&CAN, &TX);
}

/*Configura la ganancia proporcional Kp he integral Ki del vector de velocidad, si es bajo el motor se mueve mas lento (no igual a suave), si es alta
se mueve mas rapido (no igual a brusco), sin embargo si la ganancia es demasiada puede provocar vibraciones y tirones en el motor
Debido a la parte integral (Ki).*/

void Set_Vel_Gains(Axis Axis, float Vel_Gain, float Vel_Int_Gain){
	Set_TX_Param(Axis.AXIS_ID, SET_VEL_GAINS, CAN_ID_Standard, CAN_Frame_Data, 8);
	uint8_t *ptrVelGain;
	ptrVelGain = (uint8_t *)&Vel_Gain;
	uint8_t *ptrVelIntGain;
	ptrVelIntGain = (uint8_t *)&Vel_Int_Gain;
	TX.data[0] = ptrVelGain[0];
	TX.data[1] = ptrVelGain[1];
	TX.data[2] = ptrVelGain[2];
	TX.data[3] = ptrVelGain[3];
	TX.data[4] = ptrVelIntGain[0];
	TX.data[5] = ptrVelIntGain[1];
	TX.data[6] = ptrVelIntGain[2];
	TX.data[7] = ptrVelIntGain[3];
	CAN_Send_Packet(&CAN, &TX);
}

//Cambia la ID de un motor que ya tenia una ID previamente asignada

void Set_Axis_Node_ID(Axis Axis, uint32_t node_id){
	Set_TX_Param(Axis.AXIS_ID, SET_AXIS_NODE_ID, CAN_ID_Standard, CAN_Frame_Data, 4);
	uint8_t *ptrNodeId;
	ptrNodeId = (uint8_t *)&node_id;
	TX.data[0] = ptrNodeId[0];
	TX.data[1] = ptrNodeId[1];
	TX.data[2] = ptrNodeId[2];
	TX.data[3] = ptrNodeId[3];
	CAN_Send_Packet(&CAN, &TX);
}

//Configura la velocidad limite del motor y la corriente limite que puede usar.

void Set_Limits(Axis Axis, float vel_lim, float curr_lim){
	Set_TX_Param(Axis.AXIS_ID, SET_LIMITS, CAN_ID_Standard, CAN_Frame_Data, 8);
	uint8_t *ptrVelLim;
	ptrVelLim = (uint8_t *)&vel_lim;
	uint8_t *ptrCurrLim;
	ptrCurrLim = (uint8_t *)&curr_lim;
	TX.data[0] = ptrVelLim[0];
	TX.data[1] = ptrVelLim[1];
	TX.data[2] = ptrVelLim[2];
	TX.data[3] = ptrVelLim[3];
	TX.data[4] = ptrCurrLim[0];
	TX.data[5] = ptrCurrLim[1];
	TX.data[6] = ptrCurrLim[2];
	TX.data[7] = ptrCurrLim[3];
	CAN_Send_Packet(&CAN, &TX);

}


/** @brief Esta funcion recibe mensajes del Odrive
 * 
 * @details Por medio de la interrupcion de recepcion de datos en el buffer RX se puede utilziar esta funcion para recibir el ID del motor y el ID
 * del tipo de mensaje que se intenta transmitir, luego se ramifica con switch para elegir que acciones tomar y como leer el mensaje segun 
 * el que sea.
 * 
 * todas las funciones anteriores envian instrucciones, sin embargo las instrucciones que solicitan informacion no son aptas para recibir el mensaje,
 * para ello se utiliza la funcion ODrive_RX_CallBack, que recibe el mensaje solicitado por las funciones de arriba.
 * 
 */

void ODrive_RX_CallBack(Axis *AXIS){
	int32_t ID = 0;
	CAN_Get_Packet(&CAN, &RX);
	ID = RX.ID;
	int32_t NODE_ID = (ID >> 5);
	int32_t CMD_ID = (ID & 0x01F);


	if(NODE_ID == AXIS->AXIS_ID){

		switch(CMD_ID){

			case ODRIVE_HEARTBEAT_MESSAGE:
				AXIS->AXIS_Error = (RX.data[0] | RX.data[1]<<8 | RX.data[2]<<16 | RX.data[3]<<24);
				AXIS->AXIS_Current_State = RX.data[4];
				AXIS->Controller_Status = RX.data[5];
				break;


			case ENCODER_ESTIMATES: ;

				uint32_t *ptrEncPos;
				ptrEncPos = (uint32_t *)&(AXIS->AXIS_Encoder_Pos);
				*ptrEncPos = (RX.data[0] + (RX.data[1]<<8) + (RX.data[2]<<16) + (RX.data[3]<<24));
				uint32_t *ptrEncVel;
				ptrEncVel = (uint32_t *)&(AXIS->AXIS_Encoder_Vel);
				*ptrEncVel = (RX.data[4] + (RX.data[5]<<8) + (RX.data[6]<<16) + (RX.data[7]<<24));
				break;

			case GET_ENCODER_COUNT:
				AXIS->AXIS_Encoder_Shadow = (RX.data[0] | RX.data[1]<<8 | RX.data[2]<<16 | RX.data[3]<<24);
				AXIS->AXIS_Encoder_CPR = (RX.data[4] | RX.data[5]<<8 | RX.data[6]<<16 | RX.data[7]<<24);
				break;

			case GET_BUS_VOLTAGE_CURRENT: ;

				uint32_t *ptrBusV;
				ptrBusV = (uint32_t *)&(AXIS->AXIS_Bus_Voltage);
				*ptrBusV = (RX.data[0] + (RX.data[1]<<8) + (RX.data[2]<<16) + (RX.data[3]<<24));
				uint32_t *ptrBusI;
				ptrBusI = (uint32_t *)&(AXIS->AXIS_Bus_Current);
				*ptrBusI = (RX.data[4] + (RX.data[5]<<8) + (RX.data[6]<<16) + (RX.data[7]<<24));
				break;


			case GET_IQ: ;

				uint32_t *ptrIqSet;
				ptrIqSet = (uint32_t *)&(AXIS->AXIS_Iq_Setpoint);
				*ptrIqSet = (RX.data[0] + (RX.data[1]<<8) + (RX.data[2]<<16) + (RX.data[3]<<24));
				uint32_t *ptrIqMsr;
				ptrIqMsr = (uint32_t *)&(AXIS->AXIS_Iq_Measured);
				*ptrIqMsr = (RX.data[4] + (RX.data[5]<<8) + (RX.data[6]<<16) + (RX.data[7]<<24));
				break;


		}
	}
}
