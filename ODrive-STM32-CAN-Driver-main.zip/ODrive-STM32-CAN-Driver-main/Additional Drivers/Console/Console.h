/*
 * Console.h
 *
 *  Created on: Nov 14, 2021
 *      Author: Kunal
 */

#ifndef CONSOLE_CONSOLE_H_
#define CONSOLE_CONSOLE_H_

#include "main.h"


  void Console_Init(int baudrate);
  void printConsole(char *msg, ...);


#endif /* CONSOLE_CONSOLE_H_ */
