


#include "CAN.h"


/**
 * Similar a lo que se explica en las siguientes funciones
 */
int CAN_Init(CAN_Init_Typedef *init)
{
    RCC -> APB1ENR &= ~RCC_APB1ENR_CAN1EN;
    GPIO_Pin_Setup(GPIOA, 12, ALTERNATE_FUNCTION_OUTPUT_PUSHPULL, 9);
    GPIO_Pin_Setup(GPIOA, 11, ALTERNATE_FUNCTION_OUTPUT_PUSHPULL, 9);
    RCC -> APB1ENR |= RCC_APB1ENR_CAN1EN;


	init -> CAN_INSTANCE -> MCR	|= CAN_MCR_INRQ;
	init -> CAN_INSTANCE -> MCR |= CAN_MCR_NART;
	init -> CAN_INSTANCE -> IER |= init -> interrupt;
	init -> CAN_INSTANCE -> BTR = init -> baudrate;

	return 1;
}

/** @brief El filtro de CAN es una configuracion de hardware que permite distinguir los mensajes por IDs permitidas o no permitidas.
 * 
 * Por ejemplo si tomamos el rango de 0x100 - 0x1FF todas las direcciones ID de Odrive que esten dentro de ese rango podran comunicarse 
 * por el bus CAN y sus mensajes seran recibidos, mientras que las ID que esten fuera de este rango no podran comunicarse con el STM32.
 * 
 * Sin esta configuracion cualquier mensaje seria recibido  y no se sabria a que dispositivo pertenece, lo que puede causar una
 * malinterpretacion de los datos
 */


int CAN_Filter_Init(CAN_Init_Typedef *init, CAN_Filter_TypeDef *filter)
{
	uint32_t can_id = 0;
	init -> CAN_INSTANCE -> FMR |= CAN_FMR_FINIT;

	if(filter->filter_id > 13)
	{
		return -1;
	}
	else
	{
// ID INFORMATION
		if(filter -> id_type == CAN_ID_Standard)
		{
			can_id = (filter->ID << 21) | 0;
		}
		else
		{
			can_id = (filter->ID << 3) | 4;
		}

		if(filter -> frame_type == CAN_Frame_Remote)
		{
			can_id |= 2;
		}

		init -> CAN_INSTANCE -> FA1R &= ~(1 << filter -> filter_id);

		init -> CAN_INSTANCE -> FS1R |=  (1 << filter -> filter_id);

		init -> CAN_INSTANCE -> sFilterRegister[filter->filter_id].FR1 = can_id;
		init -> CAN_INSTANCE -> sFilterRegister[filter->filter_id].FR2 = can_id;

		init -> CAN_INSTANCE -> FFA1R &= ~(1 << filter->filter_id);
		init -> CAN_INSTANCE -> FA1R  |= (1 << filter->filter_id);

		init -> CAN_INSTANCE -> FMR &= ~CAN_FMR_FINIT;

	}
	return 1;
}


/*
Aqui se inicializan algunas configuraciones de CAN, no se puede obtener informacion directamente ya que estan ocultas en la libreria
HAL de STM32, y los comentarios del codigo se realizan desde Visual Studio Code.

De todas formas los nombres son macros que representan numeros enteros o incluso booleanos de 1 y 0, los macros se utilizan para dar mas
legibilidad al codigo sobre que significa la accion que se esta llevando a cabo.
*/


void CAN_Start(CAN_Init_Typedef *init)
{
	init -> CAN_INSTANCE -> MCR &= ~CAN_MCR_SLEEP;
	init -> CAN_INSTANCE -> MCR &= ~CAN_MCR_INRQ;
	while((init -> CAN_INSTANCE -> MSR & CAN_MSR_SLAK)){}
	while((init -> CAN_INSTANCE ->MSR & CAN_MSR_INAK));
}

/** @param CAN_Init_Typedef *init: Estructura de configuracion de CAN nativa de la libreria HAL en STMCubeIDE, contiene el acceso
 * a registros de configuracion del protocolo CAN asi como el acceso a los buffers y disparador de la comunicacion.
 * @param CAN_TX_Typedef *tx: Esta estructura contiene los datos a enviar y la configuracion de la transmision.
 * 
 * @note Ambos son punteros, por lo que se pasa la direccion de la estructura, de lo contrario los cambios realizados no se guardarian,
 * la direccion se puede pasar usando un puntero o usando el caracter "&", que remplaza la instancia de la estructura por su direccion
 * 
 * @example CAN_Send_Packet(&CAN_Configuration, &CAN_Transmission);
 */


void CAN_Send_Packet(CAN_Init_Typedef *init, CAN_TX_Typedef *tx)
{

/** @note Se borra toda la informacion almacenada en los registros de CAN para impedir que quede informacion residual de mensajes anteriores,
 * asi cada vez que se llama a la funcion la memoria se limpia y se asegura que el mensaje enviado sera solo el deseado.init
 * 
 * @param 0xFFFFFFF: En formato Hexagecimal esto representa a todos los bits del registro, ya que cada combinacion del formato hexagecimal
 * es una configuracion diferente de los bits internos del registro, por lo que 0xFFFFFFFF engloba a todos los bits
 * 
 * @param Bit_Banding: Aqui se usa "&= ~" para poner en 0 todos los bits del registro, como 0xFFFFFFFF engloba a todos los bits
 * y la operacion logica "&= ~" pone en 0 cualquier bit seleccionado esta combinacion elimina todo lo almacenado previamente en los registros.
 */


	init -> CAN_INSTANCE -> sTxMailBox[0].TDHR &= ~0xFFFFFFFF;
	init -> CAN_INSTANCE -> sTxMailBox[0].TDLR &= ~0xFFFFFFFF;
	init -> CAN_INSTANCE -> sTxMailBox[0].TDTR &= ~0xFFFFFFFF;
	init -> CAN_INSTANCE -> sTxMailBox[0].TIR  &= ~0xFFFFFFFF;
//---------------------------------------------------------------------------------------------------------------------

/** @note Se configura el ID y el tipo de frame en los siguientes dos bloques
 * 
 * @param tx: la estructura tx contiene entre sus miembros el ID, el tipo de ID y el tipo de frame, los cuales se configuran previamente en el codigo
 * main.c o void app_main(void), por lo tanto se pasa como argumento de la funcion la direccion de esta estructura, y por medio de la ramificacion
 * de switch se elige un caso u otro segun el tipo de ID asignado, la ID tipo estandar es la usada por los Odrive, por lo que la ID extendida no se aplica
 * para el proyecto en general.
 * 
 * @param ID: La ID de la estructura ya viene configurada con el desplazamiento de bits correspondiente segun indica Odrive,
 * es decir un desplazamiento de 6 bits para la ID del motor y un desplazamiento de 5 bits para la ID del comando,
 * esto se veria asi: tx.ID = (ID_Motor << 6) | (ID_Instruccion << 5);
 */

	switch (tx->id_type)
	{
		case CAN_ID_Standard:
		{
			init -> CAN_INSTANCE -> sTxMailBox[0].TIR  = tx->ID << 21;
			init -> CAN_INSTANCE -> sTxMailBox[0].TIR  &= ~1 << 2;
		}
			break;
		case CAN_ID_Extended:
		{
			init -> CAN_INSTANCE -> sTxMailBox[0].TIR  = tx->ID << 3;
			init -> CAN_INSTANCE -> sTxMailBox[0].TIR  |= 1 << 2;
		}
			break;
	}
//---------------------------------------------------------------------------------------------------------------------
	switch (tx->frame_type)
	{
		case CAN_Frame_Data:
		{
			init -> CAN_INSTANCE -> sTxMailBox[0].TIR  &= ~(1 << 1);
		}
			break;
		case CAN_Frame_Remote:
		{
			init -> CAN_INSTANCE -> sTxMailBox[0].TIR  |= (1 << 1);
		}
			break;
	}
//---------------------------------------------------------------------------------------------------------------------
/** @brief Esta seccion se usa para cargar el mensaje en el buffer del STM32
 * 
 *  @param CAN_INSTANCE: Estructura anidada que contiene un arreglo de subestructura llamado @param sTxMailBox
 * Esta subestructura contiene los registros de hardware que permiten almacenar de manera pura y directa
 * las configuraciones del mensaje a enviar asi como el mensaje mismo.
 * 
 * @param TDTR: Contiene la longitud del mensaje a enviar
 * 
 * @param TDLR: Contiene los primeros 4 Bytes a enviar
 * 
 * @param TDHR: Contiene los ultimos 4 Bytes a enviar
 * 
 * @param TIR: Es el disparador, al poner en 1 el primer bit del registro el mensaje se envia por el bus de datos CAN
 * 
 * @note La linea: while(init -> CAN_INSTANCE -> sTxMailBox[0].TIR & (1 << 0)){}
 * produce una espera activa de bucle infinito hasta que el el primer bit de TIR se ponga en 0,
 * esto asegura que se envie todo el mensaje antes de seguir con el codigo, por lo que se considera una
 * tecnica bloqueante, util para seguridad y evitar perdida de datos, poco util si hay que realizar tareas simultaneamente.
 * 
 */ 




	init -> CAN_INSTANCE -> sTxMailBox[0].TDTR = tx->data_length; //Longitud del mensaje (Generalmente 8 bytes, que es lo maximo para Basic CAN)
	init -> CAN_INSTANCE -> sTxMailBox[0].TDTR &= ~CAN_TDT0R_TGT;
	init -> CAN_INSTANCE -> sTxMailBox[0].TDHR = tx->data[7] << 24 | tx->data[6] << 16 | tx->data[5] << 8 | tx->data[4] << 0; //Ultimos 4 bytes
	init -> CAN_INSTANCE -> sTxMailBox[0].TDLR = tx->data[3] << 24 | tx->data[2] << 16 | tx->data[1] << 8 | tx->data[0] << 0; //Primeros 4 bytes
	init -> CAN_INSTANCE -> sTxMailBox[0].TIR  |= (1 << 0); //Al poner en 1 el primer bit de TIR se envia el mensaje precargado
	while(init -> CAN_INSTANCE -> sTxMailBox[0].TIR & (1 << 0)){}

}



/** @brief Proceso muy parecido al anterior, pero dirigido a la recepcion de datos.
 * Aqui en vez de cargar datos y enviarlos con el disparador se escucha atentamente configurando una interrupcion por recibimiento de datos.
 * Cuando la interrupcion sucede esta funcion entra en accion y recibe byte por byte la informacion del Odrive.
 * 
 * Se selecciona el tipo de ID, frame y se conjugan algunos registros para recibir el mensaje enviando al buffer de RX
 */

void CAN_Get_Packet(CAN_Init_Typedef *init, CAN_RX_Typedef *rx)
{


	int frame_type = 0;
	int id_type = 0;



	id_type =  (CAN1 -> sFIFOMailBox[0].RIR & CAN_RI0R_IDE_Msk) >> CAN_RI0R_IDE_Pos ;
	frame_type = (CAN1 -> sFIFOMailBox[0].RIR & CAN_RI0R_RTR_Msk) >> CAN_RI0R_RTR_Pos ;

	if(id_type)
	{
		//Extended ID
		rx->id_type = CAN_ID_Extended;
		rx->ID = (init -> CAN_INSTANCE -> sFIFOMailBox[0].RIR & CAN_RI0R_EXID_Msk) >> CAN_RI0R_EXID_Pos;
	}
	else
	{
		//Standard ID
		rx->id_type = CAN_ID_Standard;
		rx->ID = (init -> CAN_INSTANCE -> sFIFOMailBox[0].RIR & CAN_RI0R_STID_Msk) >> CAN_RI0R_STID_Pos;
	}

	if(frame_type)
	{
		//RTR Frame
		rx->frame_type = CAN_Frame_Remote;
		rx->data_length = (init -> CAN_INSTANCE -> sFIFOMailBox[0].RDTR & CAN_RDT0R_DLC_Msk) >> CAN_RDT0R_DLC_Pos;
		init -> CAN_INSTANCE -> RF0R |= CAN_RF0R_RFOM0;
		while((init -> CAN_INSTANCE -> RF0R & CAN_RF0R_RFOM0)){}
	}
	else
	{
		//Data Frame
		rx->frame_type = CAN_Frame_Data;
		rx->data_length = (init -> CAN_INSTANCE -> sFIFOMailBox[0].RDTR & CAN_RDT0R_DLC_Msk) >> CAN_RDT0R_DLC_Pos;
		for(int i = 0; i < rx->data_length; i++)
		{
			if(i < 4)
			{
				rx->data[i] =  (init -> CAN_INSTANCE -> sFIFOMailBox[0].RDLR & ( 0xFF << (8*i))) >> (8*i);
			}
			else
			{
				rx->data[i] =  (init -> CAN_INSTANCE -> sFIFOMailBox[0].RDHR & ( 0xFF << (8*(i-4)))) >> (8*(i-4));
			}
		}

		init -> CAN_INSTANCE -> RF0R |= CAN_RF0R_RFOM0;	}


}
