
#ifndef CAN_H_
#define CAN_H_

#include "main.h"
#include "GPIO.h"
#include "CAN_defines.h"

/** @brief Los archivos .h permiten declarar las funciones, tipos de dato a usar, macros y estructuras mas no definirlos.abort
 * 
 * los archivos de esta indole solo pueden hacer mencion a los nombres de los datos y fuciones a usar, mientras que la definicion
 * y contenido de las funciones y datos se realiza en los archivos .c, si alguno de los dos falta se genera un error de compilacion,
 * si se intenta definir una variable o el contenido de una funcion en el archivo .h se generara un error de compilacion.
 * 
 * Este archivo es tambien una forma rapida de ver las funciones y datos que tienen las estructuras que se veran en el archivo .c,
 * por lo que puede clarificar la lectura ver primero la mencion de los datos y luego su definicion.
 */


/** @note los nombres usados en #define son para simplificar el codigo, la libreria HAL contiene los macros de tipo CAN_IER,
 * sin embargo reasignando estos macros a una mascara creada con #define el codigo se vuelve mas legible y entendible ya que en compilacion
 * Transmit_Mailbox_Empty se susituye por CAN_IER_TMEIE.
 */

#define Transmit_Mailbox_Empty	CAN_IER_TMEIE
#define Fifo0_Message_Pending	CAN_IER_FMPIE0
#define Fifo1_Message_Pending	CAN_IER_FMPIE1
#define Fifo0_Full				CAN_IER_FFIE0
#define Fifo1_Full				CAN_IER_FFIE1
#define Fifo0_Overflow			CAN_IER_FOVIE0
#define Fifo1_Overflow			CAN_IER_FOVIE1


/** @brief Generalidades en los datos de las estructuras (Explicacion a mayor detalle en el archivo CAN.c)
 * @param id_type: Almacena el tipo de identificador del mensaje, es decir tipo estandar o tipo extendido
 * @param data_lenght: Almacena el largo del mensaje en bytes, para Basic CAN el maximo es 8 bytes almacenables en memoria
 * @param data[]: Este arreglo almacena los 8 bytes del mensaje despues de organizarlos por little endian
 * @param ID: Almacena el ID de la instruccion y el ID del motor a controlar
 * @param interrupt: almacena el tipo de interrupcion a usar cuando se reciba un mensaje
 * @param Baudrate: Es la velocidad de transmision del bus CAN, dada en bits por segundo, lo comun es 115200 en MCU de 100Mhz para arriba
 * @param Frame_type: El frame es el marco de gestion de la informacion, refiriendonos a como se recibe, como se retroalimenta al emisor 
 * del estado de la recepcion, que tipo de identificador se usa y si el mensaje es de envio o de recepcion, al igual que los ID estan
 * los frames de tipo estandar y extendido.
 * 
 */



typedef struct CAN_RX_Typedef
{
	int message_timestamp;
	int data_length;
	int data[8];
	int filter_index;
	int frame_type;
	int id_type;
	int32_t ID;
}CAN_RX_Typedef;

typedef struct CAN_Filter_TypeDef{
	int filter_id;
	int enable;
	int id_type;
	int frame_type;


	int type;
	int scale;
	int bank_id;
	uint32_t ID;
}CAN_Filter_TypeDef;

typedef struct CAN_TX_Typedef{
	int id_type;
	int frame_type;
	int send_timestamp;
	int32_t ID;
	int data_length;
	int data[8];
}CAN_TX_Typedef;

typedef struct CAN_Init_Typedef
{
	CAN_TypeDef *CAN_INSTANCE;			//CAN1 OR CAN2
	int32_t baudrate;
	int timestamp_enable;
	int interrupt;
}CAN_Init_Typedef;


/*
Todas las funciones mencionadas aqui se explican en el archivo CAN.c
*/

int CAN_Init(CAN_Init_Typedef *init);

int CAN_Filter_Init(CAN_Init_Typedef *init, CAN_Filter_TypeDef *filter);

void CAN_Start(CAN_Init_Typedef *init);

void CAN_Send_Packet(CAN_Init_Typedef *init, CAN_TX_Typedef *tx);

void CAN_Get_Packet(CAN_Init_Typedef *init, CAN_RX_Typedef *rx);

#endif /* CAN_H_ */
