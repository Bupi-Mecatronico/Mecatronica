"# Mecatronica" 
