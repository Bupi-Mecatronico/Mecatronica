
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include "string.h"
#include "stdbool.h"
#include "stdlib.h"
#include "stdarg.h"
#include "stdint.h"
#include "stdlib.h"
#include "stdio.h"
#include "inttypes.h"
#include "math.h"







void Error_Handler(void);


#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
